import libtcodpy as libtcod
import math, random

# size of the window
SCREEN_WIDTH = 80
SCREEN_HEIGHT = 50

# These variables contain the size of the game map.
MAP_WIDTH = 80
MAP_HEIGHT = 40

# These are the lightened tile colors.
WALL_COLOR = libtcod.Color (95, 95, 95)
FLOOR_COLOR = libtcod.Color (127, 127, 127)
DOOR_COLOR = libtcod.orange

# These are the darkened tile colors.
DARK_WALL_COLOR = libtcod.Color (31, 31, 31)
DARK_FLOOR_COLOR = libtcod.Color(63, 63, 63)
DARK_DOOR_COLOR = libtcod.dark_orange

ROOM_MAX_SIZE = 10
ROOM_MIN_SIZE = 6
MAX_ROOMS = 30

# Settings
ENEMY_SPAWN_CHANCE = 0.15
ZOMBIE_MOVE_CHANCE = 0.5

# Set the fps.
libtcod.sys_set_fps(45)

# Set the font.
libtcod.console_set_custom_font ('consolas12x12_gs_tc.png',
                                 libtcod.FONT_TYPE_GREYSCALE
                                 | libtcod.FONT_LAYOUT_TCOD)

# Start the required consoles.
libtcod.console_init_root (SCREEN_WIDTH, SCREEN_HEIGHT, 'rogue.py', False)
game_console = libtcod.console_new(MAP_WIDTH, MAP_HEIGHT)
menu_console = libtcod.console_new(SCREEN_WIDTH, SCREEN_HEIGHT)
status_console = libtcod.console_new(SCREEN_WIDTH, (SCREEN_HEIGHT - MAP_HEIGHT))

# Hide the OS cursor.
libtcod.mouse_show_cursor (False)

# Seed the random number generator with the system time.
random.seed ()

##################
## Game objects ##
##################


# This is a gameworld tile object.
class Tile:

  def __init__ (self, blocked=True):
    self.blocked = blocked
    self.characters = []
    self.items = []
    self.explored = False

  # This returns true if the tile is blocked (i.e. it is a wall),
  # otherwise it returns false.
  def is_blocked (self):
    return self.blocked

  # This blocks the tile.
  def block (self):
    self.blocked = True

  def unblock (self):
    self.blocked = False

# This is a generic game object.
class Object:

  def __init__ (self, name, x, y, char, color):
    self.name = name
    self.x = x
    self.y = y
    self.char = char
    self.color = color
    gameworld[self.x][self.y].items.append(self)

  def is_hostile (self):
    return False

  def get_x (self):
    return self.x

  def get_y (self):
    return self.y

class Item (Object):
  def __init__ (self, name, x, y, char, color, gun=None, money=None, health=None):
    self.name = name
    self.x = x
    self.y = y
    self.char = char
    self.color = color
    self.gun = gun
    self.money = money
    self.health = health
    gameworld[self.x][self.y].items.append(self)
    if self.gun:
      self.gun.owner = self
      self.name = self.name + ' (' + str(self.gun.ammo) + ')'
    if self.money:
      self.money.owner = self
    if self.health:
      self.health.owner = self

class Health ():
  def __init__ (self, value):
    self.value=value

class Money ():
  def __init__ (self, value):
    self.value = value

class Gun ():
  def __init__ (self, damage=10, accuracy=0.5, ammo=15):
    self.damage = damage
    self.accuracy = accuracy
    self.ammo=ammo

  def fire(self, x, y, dx, dy):
    # The distance this bullet has traveled.
    steps = 0
    shot_accuracy=self.accuracy
    libtcod.map_compute_fov (player.fov, x, y, int(player.view_distance*1.5),
                              True,libtcod.FOV_SHADOW)
    render()
    libtcod.line_init(x, y, dx, dy)
    lx,ly=libtcod.line_step()
    while (not lx is None):
      steps = steps + 1
      if not gameworld[lx][ly].characters:
        libtcod.console_set_back(game_console, lx, ly, libtcod.white, libtcod.BKGND_OVERLAY)
        libtcod.console_blit(game_console,0,0,MAP_WIDTH,MAP_HEIGHT,0,0,0,1)
        libtcod.console_flush()
        lx,ly=libtcod.line_step()
      else:
        if random.random() <= shot_accuracy:
          add_status("You hit!")
          gameworld[lx][ly].characters[-1].take_damage(int(self.damage*random.uniform(self.accuracy, 1.0)))
        else:
          add_status("You fire and miss!")
        break
    self.ammo = self.ammo-1
    self.owner.name = self.owner.name.rsplit('(')[0] + '(' + str(self.ammo) + ')'
    player.compute_fov()

# This is a generic character object.
class Character (Object):

  def __init__ (self, name, max_health, x, y, char, color, npc=False, strength=5, to_hit=0.8):
    self.name = name
    self.health = max_health
    self.max_health = max_health
    self.x = x
    self.y = y
    self.char = char
    self.color = color
    self.items = []
    self.hand = None
    self.npc = npc
    self.strength = strength
    self.to_hit = to_hit
    gameworld[self.x][self.y].characters.append(self)

  def move (self, dx, dy):
    if gameworld[self.x + dx][self.y + dy].characters or gameworld[self.x + dx][self.y + dy].is_blocked():
      characters = gameworld[self.x + dx][self.y + dy].characters
      if characters:
        for character in characters:
          if not character.npc:
            self.attack(character)
    else:
      gameworld[self.x][self.y].characters.remove(self)
      self.x = self.x + dx
      self.y = self.y + dy
      gameworld[self.x][self.y].characters.append(self)

  def pick_up(self):
    if gameworld[self.x][self.y].items:
      item = gameworld[self.x][self.y].items.pop()
      self.items.append(item)

  def drop(self):
    if self.items:
      item = self.items.pop()
      gameworld[self.x][self.y].items.append(item)

  def drop_all(self):
    for item in self.items:
      self.items.remove(item)
      gameworld[self.x][self.y].items.append(item)

  # Moves toward coordinates. Only moves one step.
  def move_to_coordinates (self, dx, dy):
    if dx > self.x:
      newx = 1
    elif dx < self.x:
      newx = -1
    else:
      newx = 0
    if dy > self.y:
      newy = 1
    elif dy < self.y:
      newy = -1
    else:
      newy = 0
    self.move(newx, newy)

  # Set the character's health.
  def set_health (self, health):
    self.health = health

  def attack (self, character):
    damage = self.strength*random.randint(self.strength/2, self.strength*2)
    if random.random() <= self.to_hit:
      add_status("%s hits %s!" % (self.name, character.name))
      if damage > (0.5*character.max_health):
        add_status("It's super effective!")
      character.take_damage(damage)
    else:
      add_status("%s swings and misses." % (self.name))

  def take_damage (self, damage):
    self.health -= damage

    if 0 > self.health:
      add_status("%s is killed!" % (self.name))
      self.health = 0
      gameworld[self.x][self.y].characters.remove(self)
      self.drop_all()

class Player(Character):

  def __init__ (self, name, max_health, x, y, char, color, view_distance=10, strength=5, to_hit=0.8):
    self.name = name
    self.health = max_health
    self.max_health = max_health
    self.x = x
    self.y = y
    self.char = char
    self.color = color
    self.items = []
    self.equipped = []
    self.hand = None
    self.view_distance = view_distance
    self.strength = strength
    self.to_hit = to_hit
    self.fov = libtcod.map_new(MAP_WIDTH, MAP_HEIGHT)
    self.npc = False
    self.exp = 0
    gameworld[self.x][self.y].characters.append(self)
    self.compute_fov()

  def move (self, dx, dy):
    if gameworld[self.x + dx][self.y + dy].characters or gameworld[self.x + dx][self.y + dy].is_blocked():
      characters = gameworld[self.x + dx][self.y + dy].characters
      if characters:
        for object in characters:
          self.attack(object)
    else:
      gameworld[self.x][self.y].characters.remove(self)
      self.x = self.x + dx
      self.y = self.y + dy
      gameworld[self.x][self.y].characters.append(self)
      for item in gameworld[self.x][self.y].items:
        add_status("A %s."% (item.name))
    self.compute_fov()

  def show_inventory(self):
    if self.items:
      item = item_selector(self.items, equipped=self.equipped)
      if item:
        if item.health:
          self.health = self.health+item.health.value
          if self.health > self.max_health:
            self.health = self.max_health
            add_status("%s health added." % (item.health.value))
          self.items.remove(item)
        else:
          if not self.hand == item:
            self.hand=item
            add_status("%s equipped." % (self.hand.name))
          else:
            add_status("%s unequipped." % (self.hand.name))
            self.hand = None

  def compute_fov(self):
    for x in range (MAP_WIDTH):
      for y in range (MAP_HEIGHT):
        if not gameworld[x][y].is_blocked ():
         libtcod.map_set_properties (self.fov, x , y, True, True)
    libtcod.map_compute_fov (self.fov, self.x, self.y, self.view_distance,
                            True,libtcod.FOV_SHADOW)

  def pick_up(self):
    if gameworld[self.x][self.y].items:
      if len(gameworld[self.x][self.y].items) > 1:
        item = item_selector(gameworld[self.x][self.y].items)
      else:
        item = gameworld[self.x][self.y].items[0]
      gameworld[self.x][self.y].items.remove(item)
      if item.money:
        self.money = self.money + item.money.value
      else:
        self.items.append(item)
      add_status ("%s picked up %s." % (self.name, item.name))
    else:
      add_status ("Nothing to pick up!")

  def drop(self):
    if self.items:
      items = self.items[:]
      if self.hand:
        items.remove(self.hand)
      if items:
        item = item_selector(items)
        if item:
          self.items.remove(item)
          gameworld[self.x][self.y].items.append(item)
          add_status("%s dropped %s." % (self.name, item.name))
      else:
        add_status("Nothing to drop!")

  # Aim and shoot the player's gun.
  def shoot(self):
    if self.hand and self.hand.gun and self.hand.gun.ammo > 0:
      class Target:
       def __init__(self, x, y):
          self.x = x
          self.y = y
      target = Target(self.x, self.y)
      libtcod.console_blit(game_console,0,0,MAP_WIDTH,MAP_HEIGHT,0,0,0,1)
      libtcod.console_flush()
      key = libtcod.console_wait_for_keypress(True)
      while not key.vk == libtcod.KEY_SPACE:
        render()
        if ord('8') == key.c:
          target.y=target.y-1
        elif ord('k') == key.c:
          target.y=target.y+1
        elif ord('u') == key.c:
          target.x=target.x-1
        elif ord('o') == key.c:
          target.x=target.x+1
        elif ord('7') == key.c:
          target.x=target.x-1
          target.y=target.y-1
        elif ord('9') == key.c:
          target.x=target.x+1
          target.y=target.y-1
        elif ord('j') == key.c:
          target.x=target.x-1
          target.y=target.y+1
        elif ord('l') == key.c:
          target.x=target.x+1
          target.y=target.y+1
        libtcod.line_init(self.x, self.y, target.x, target.y)
        x,y=libtcod.line_step()
        while (not x is None):
          if not gameworld[x][y].is_blocked() and libtcod.map_is_in_fov (player.fov, x, y):
            libtcod.console_set_back(game_console, x, y, libtcod.white, libtcod.BKGND_OVERLAY)
            target.x=x
            target.y=y
            x,y=libtcod.line_step()
          else:
            break
        libtcod.console_blit(game_console,0,0,MAP_WIDTH,MAP_HEIGHT,0,0,0,1)
        libtcod.console_flush()
        key = libtcod.console_wait_for_keypress(True)
      self.hand.gun.fire(self.x, self.y, target.x, target.y)
    else:
      add_status("No gun in hand!")

###############################
## Game generation functions ##
###############################


# Generate a map
def generate_gameworld ():
  class Room:
    def __init__(self,x,y,w,h):
      self.x1=x
      self.y1=y
      self.x2=x+w
      self.y2=y+h
      carve_room(self)

  def carve_room(room):
    for x in range(room.x1 + 1, room.x2):
        for y in range(room.y1 + 1, room.y2):
            gameworld[x][y].unblock()

  global gameworld
  gameworld = [[Tile (True) for y in range (MAP_HEIGHT)]
                for x in range (MAP_WIDTH)]
  Room(0,0,MAP_WIDTH-1,MAP_HEIGHT-1)

  for i in range(30):
    gameworld[10][i].block()

  gameworld[10][15].unblock()

  for i in range(9):
    gameworld[10][i+31].block()

  for x in range(40):
    gameworld[x][20].block()

  gameworld[6][20].unblock()

  for i in range(9):
    gameworld[30][i].block()

  for i in range(9):
    gameworld[30+i][9].block()

######################
## Status functions ##
######################

# Displays the parsed string as a status message to the user.
# Doesn't display strings larger than SCREEN_WIDTH yet.
def display_status ():
  global status
  if status:
    libtcod.console_rect(status_console, 0, 0, SCREEN_WIDTH, (SCREEN_HEIGHT - MAP_HEIGHT), True)
    libtcod.console_set_foreground_color (status_console, libtcod.white)
    while len(status) > SCREEN_WIDTH*2:
      display_statusline(status[:SCREEN_WIDTH*2])
      key = libtcod.console_wait_for_keypress(True)
      while not key.vk == libtcod.KEY_SPACE:
        key = libtcod.console_wait_for_keypress(True)
      status = status[SCREEN_WIDTH*2:]
    display_statusline(status)
    libtcod.console_blit(status_console,0,0,SCREEN_WIDTH,(SCREEN_HEIGHT-MAP_HEIGHT-1),0,0,MAP_HEIGHT+1,1)
  else:
    display_statusline()

def display_statusline (message=""):
  display_player_stats()
  for x in range (SCREEN_WIDTH):
    libtcod.console_put_char (status_console, x, 0, ' ', libtcod.BKGND_NONE)
    libtcod.console_put_char (status_console, x, 1, ' ', libtcod.BKGND_NONE)
    libtcod.console_print_left_rect(status_console, 1, 0, SCREEN_WIDTH, 2, libtcod.BKGND_NONE, message[:SCREEN_WIDTH*2].strip())
  libtcod.console_blit(status_console,0,0,SCREEN_WIDTH,(SCREEN_HEIGHT-MAP_HEIGHT-1),0,0,MAP_HEIGHT+1,1)
  libtcod.console_flush()

def display_player_stats():
  libtcod.console_print_left(status_console, 1, 2, libtcod.BKGND_NONE, player.name)
  libtcod.console_print_left(status_console, len(player.name)+2, 2, libtcod.BKGND_NONE, "HP: %s/%s" % (player.health, player.max_health))

def add_status (new_status):
  global status
  status = ("%s %s" % (status, new_status))

def clear_status ():
  global status
  status = ""

########################
## Gameplay functions ##
########################

def item_selector(items, default=None, equipped=[]):
  libtcod.console_rect(menu_console, 0, 0, MAP_WIDTH, MAP_HEIGHT, True)
  libtcod.console_print_center(menu_console , MAP_WIDTH/2, 0, libtcod.BKGND_NONE, "INVENTORY")
  libtcod.console_print_right(menu_console , SCREEN_WIDTH-1, SCREEN_HEIGHT-1,
    libtcod.BKGND_NONE, "[NUM8 / NUM2]: Select item [t]: info [SPACEBAR]: Equip [q]: quit")
  count = 0
  for item in items:
    libtcod.console_print_left(menu_console, 1, count+3, libtcod.BKGND_NONE, item.name)
    if item in equipped:
      libtcod.console_print_left(menu_console, len(item.name)+2, count+3, libtcod.BKGND_NONE, "(EQUIPPED)")
    count = count + 1
  if default:
    count = items.index(default)
  else:
    count = count -1
  key = libtcod.console_check_for_keypress(True)
  while not key.vk == libtcod.KEY_SPACE and not ord('q') == key.c:
    for i in range(len(items[count].name)):
      libtcod.console_set_back(menu_console, i+1,  count+3, libtcod.white, libtcod.BKGND_SET)
      libtcod.console_set_fore(menu_console, i+1,  count+3, libtcod.black)
    if key.c == ord('8') and count > 0:
      for i in range(len(items[count].name)):
        libtcod.console_set_back(menu_console, i+1,  count+3, libtcod.black, libtcod.BKGND_SET)
        libtcod.console_set_fore(menu_console, i+1,  count+3, libtcod.white)
      count = count -1
    elif key.c == ord('k') and count < len(items)-1:
      for i in range(len(items[count].name)):
        libtcod.console_set_back(menu_console, i+1,  count+3, libtcod.black, libtcod.BKGND_SET)
        libtcod.console_set_fore(menu_console, i+1,  count+3, libtcod.white)
      count = count +1
    libtcod.console_blit(menu_console,0,0,SCREEN_WIDTH,SCREEN_HEIGHT,0,0,0,1)
    libtcod.console_flush()
    key = libtcod.console_check_for_keypress(True)
  if not ord('q') == key.c:
    return items[count]

# Get user input and update game accordingly.
def handle_keys (key):
  global turncount
  turn = False
  # Exit the game on escape.
  if libtcod.KEY_ESCAPE == key.vk:
    return True

  # If there's not a special keypress, check normal key input.
  if player.health > 0:
    if ord('i') == key.c:
      turn = True
    elif ord('8') == key.c:
      player.move (0, -1)
      turn = True
    elif ord('k') == key.c:
      player.move (0, 1)
      turn = True
    elif ord('u') == key.c:
      player.move (-1, 0)
      turn = True
    elif ord('o') == key.c:
      player.move (1, 0)
      turn = True
    elif ord('7') == key.c:
      player.move (-1, -1)
      turn = True
    elif ord('9') == key.c:
      player.move (1, -1)
      turn = True
    elif ord('j') == key.c:
      player.move (-1, 1)
      turn = True
    elif ord('l') == key.c:
      player.move (1, 1)
      turn = True
    elif ord(',') == key.c:
      player.pick_up()
      turn = True
    elif ord('d') == key.c:
      player.drop()
      turn = True
    elif ord('t') == key.c:
      player.show_inventory()
    elif ord('z') == key.c:
      player.shoot()
      turn = True
    if turn:
      # Move all enemies toward the player.
      characters = []
      for y in range (MAP_HEIGHT):
        for x in range (MAP_WIDTH):
            for character in gameworld[x][y].characters:
              characters.append(character)

      for character in characters:
        if character.npc and player.health > 0 and random.random() <= ZOMBIE_MOVE_CHANCE:
          path = libtcod.path_new_using_map(player.fov)
          # Compute the path between the hostile object and the player.
          libtcod.path_compute(path, character.get_x(), character.get_y(),
            player.get_x(), player.get_y())
          if libtcod.path_size(path) < 100:
            libtcod.path_walk(path, True)
            character.move_to_coordinates(libtcod.path_get_origin(path)[0], libtcod.path_get_origin(path)[1])
      #spawn a new zombie
      if random.random() <= ENEMY_SPAWN_CHANCE:
        x,y=find_blind_open_tile()
        Character('Zombie', random.randint(5,20), x, y, "Z", libtcod.black, npc=True)
        if random.random() <= 0.20:
          Item ('cheap revolver', x, y, 'r', libtcod.red, gun=Gun(5, 0.6))
          gameworld[x][y].characters[0].pick_up()
        if random.random() <= 0.02:
          Item ('silver revolver', x, y, 'r', libtcod.cyan, gun=Gun(15, 0.9))
          gameworld[x][y].characters[0].pick_up()
        if random.random() <= 0.10:
          Item ('medkit', x, y, 'H', libtcod.red, health=Health(100))
          gameworld[x][y].characters[0].pick_up()
      turncount = turncount + 1
      if player.health < player.max_health:
        player.heatlh = player.health + 1
  display_status()

  clear_status()
  render()
  return False

# Draws everything to the screen.
def render ():

  # Clear the game console
  libtcod.console_rect(game_console, 0, 0, MAP_WIDTH, MAP_HEIGHT, True)

  for y in range (MAP_HEIGHT):
      for x in range (MAP_WIDTH):

        # Draw black for all areas the player has not seen yet
        if not gameworld[x][y].explored:
          libtcod.console_set_back(game_console, x, y, libtcod.black, libtcod.BKGND_SET)

        # Draw all the floors.
        if not gameworld[x][y].is_blocked () and gameworld[x][y].explored:
          libtcod.console_set_back (game_console, x, y, DARK_FLOOR_COLOR, libtcod.BKGND_SET)

        # Draw all the walls.
        elif gameworld[x][y].explored:
          libtcod.console_set_back(game_console, x, y, DARK_WALL_COLOR, libtcod.BKGND_SET)

        # Draw all the light floors.
        if (libtcod.map_is_in_fov (player.fov, x, y)
           and libtcod.map_is_walkable (player.fov, x, y)):
          libtcod.console_set_back (game_console, x, y, FLOOR_COLOR, libtcod.BKGND_SET)
          for item in gameworld[x][y].items:
            libtcod.console_set_foreground_color (game_console, item.color)
            libtcod.console_put_char (game_console, x, y, item.char, libtcod.BKGND_NONE)
          for character in gameworld[x][y].characters:
            libtcod.console_set_foreground_color (game_console, character.color)
            libtcod.console_put_char (game_console, x, y, character.char, libtcod.BKGND_NONE)
          gameworld[x][y].explored=True

        # Draw all the light walls.
        elif libtcod.map_is_in_fov (player.fov, x, y):
          libtcod.console_set_back (game_console, x, y, WALL_COLOR, libtcod.BKGND_SET)
          gameworld[x][y].explored=True


  libtcod.console_blit(game_console,0,0,MAP_WIDTH,MAP_HEIGHT,0,0,0,1)

################
## Game setup ##
################

# Generate a map
generate_gameworld()

turncount = 0
# Holds the status message.
status = ""

def main_menu():
  libtcod.console_rect(game_console, 0, 0, MAP_WIDTH, MAP_HEIGHT, True)

def find_open_tile():
  x = random.randint(0,MAP_WIDTH-1)
  y = random.randint(0,MAP_HEIGHT-1)
  while gameworld[x][y].is_blocked() or gameworld[x][y].characters:
    x = random.randint(0,MAP_WIDTH-1)
    y = random.randint(0,MAP_HEIGHT-1)
  return [x,y]

def find_blind_open_tile():
  x,y=find_open_tile()
  while libtcod.map_is_in_fov (player.fov, x, y):
    x,y=find_open_tile()
  return [x,y]

def place_player():
  x,y = find_open_tile()
  global player
  player = Player ('Player', 10000, x, y, "@", libtcod.white, view_distance = 15)
  Item ('silver revolver', x, y, 'r', libtcod.cyan, gun=Gun(15, 0.9))
  Item ('silver revolver', x, y, 'r', libtcod.cyan, gun=Gun(15, 0.9))

place_player()

firstRun = True
###############
## Game loop ##
###############
while not libtcod.console_is_window_closed ():
  if not firstRun:
    key = libtcod.console_wait_for_keypress(True)
  else:
    key = libtcod.console_check_for_keypress()
  if handle_keys (key):
    break
  libtcod.console_flush ()
  firstRun = False
